﻿using System;
using System.Collections.Generic;
using System.Linq;
using LinqToDB;
using LinqToDB.Data;

namespace BookReading.Models
{
    public class DbBookContext : IBookContext
    {
        public void AddBook(Book newBook)
        {
            using (var db = new Database())
            {
                db.Insert(newBook);
                // db.InsertWithIdentity()
            }
        }

        public void AddReview(Review newReview)
        {
            //throw new System.NotImplementedException();
            using (var db = new Database())
            {
                db.InsertWithIdentity(newReview);
            }
        }

        public List<Book> GetAll()
        {
            using (var db = new Database())
            {
                return db.Books.ToList();
            }
        }

        public Book GetBook(int bookId)
        {
            using (var db = new Database())
            {
                return db.Books.SingleOrDefault(x => x.Id == bookId);
            }
        }

        public Book Update(Book newBookData)
        {
            if (newBookData == null)
                throw new ArgumentNullException(nameof(newBookData));

            using (var db = new Database())
            {
                var book =
                    db.Books.SingleOrDefault(x => x.Id == newBookData.Id);

                if (book == null)
                    return null;

                if (newBookData.Rating < 1) { newBookData.Rating = 1; };
                if (newBookData.Rating > 5) { newBookData.Rating = 5; };

                db.Update(newBookData);

                book.Update(newBookData);
                return book;
            }

        }

        public List<Book> TopTen()
        {
            using (var db = new Database())
            {
                var query = from b in db.Books
                            orderby b.Rating
                            descending
                            select b;
                return query.Take(15).ToList();
            }
        }

        public void SetRating(int id, int rating)
        {
            using (var db = new Database())
            {
                db.Books.Where(b => b.Id == id).Set(b => b.Rating, rating).Update();
            }
        }

        private class Database : DataConnection
        {
            public Database() : base("Main")
            {
            }

            public ITable<Book> Books { get { return GetTable<Book>(); } }
        }
    }
}